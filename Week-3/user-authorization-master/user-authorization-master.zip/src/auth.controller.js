const oauthService = require("./auth.service");

// Controller code which orchestrates the overall process
// It calls the service functions where the business logic is present
function oauthProcessor(code, done) {
  console.log("code=>", code);
  oauthService.getGithubAccessToken(code, (err, token) => {
    if (err) {
      console.log("error_2 ==>", err);
      done(err);
    } else {
      done(null, token);
    }
  });
}

module.exports = {
  oauthProcessor,
};
