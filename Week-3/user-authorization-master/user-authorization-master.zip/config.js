const config = {
  PORT: process.env.PORT || "3000",
  CLIENT_ID: process.env.CLIENT_ID || "aa7956e5edd85e60f088",
  CLIENT_SECRET:
    process.env.CLIENT_SECRET || "cbb4a0648c59ff8304bb1b429518ae4cba6ccbf7",
};

module.exports = config;
